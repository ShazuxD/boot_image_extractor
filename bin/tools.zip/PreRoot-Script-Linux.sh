#!/usr/bin/env bash

cd "`dirname "$0"`"
fastboot=/usr/bin/fastboot
[ ! -f $fastboot ] && echo "$fastboot not found." && exit 1
[ ! -x $fastboot ] && echo "$fastboot cannot be executed." && exit 1
echo "Waiting for device..."
device=`$fastboot getvar product 2>&1 | grep -F 'product:' | tr -s ' ' | cut -d ' ' -f 2`
[ -z "$device" ] && device='unknown'
[ "$device" != 'fleur' ] && [ "$device" != 'miel' ] && echo "Compatible devices: fleur, miel" && echo "Your device: $device" && exit 1

echo "You are going to wipe your data and internal storage."
echo "It will delete all your files and photos stored on internal storage."
read -p "Do you agree? (Y/N) " choice
[ "$choice" != 'y' ] && [ "$choice" != 'Y' ] && exit 0

echo "##################################################################"
echo "Please wait & don't disconnect your device. It will reboot when installation is finished."
echo "##################################################################"
$fastboot reboot fastboot

$fastboot erase metadata
$fastboot erase userdata
$fastboot erase md_udc

$fastboot flash boot imgs\boot-magisk.img
$fastboot flash dtbo imgs\dtbo.img
$fastboot flash vbmeta imgs\vbmeta.img
$fastboot flash vbmeta_system imgs\vbmeta_system.img
$fastboot flash system imgs\system.img
$fastboot flash vendor imgs\vendor.img
$fastboot flash product imgs\product.img
$fastboot flash audio_dsp imgs\audio_dsp.img
$fastboot flash gz imgs\gz.img
$fastboot flash lk imgs\lk.img
$fastboot flash md1img imgs\md1img.img
$fastboot flash pi_img imgs\pi_img.img
$fastboot flash preloader_raw imgs\preloader_raw.img
$fastboot flash scp imgs\scp.img
$fastboot flash spmfw imgs\spmfw.img
$fastboot flash sspm imgs\sspm.img
$fastboot flash tee imgs\tee.img
$fastboot flash vbmeta_vendor imgs\vbmeta_vendor.img

$fastboot reboot
